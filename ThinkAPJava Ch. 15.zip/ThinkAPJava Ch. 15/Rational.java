/**
 * This class describes any rational number for Exercise 11-3 and 15-4. Each class method has been rewritten as an object method instead.
 * See comments to see which function fulfills which requirement in Exercise 11-3. All functions satisfy 15-4, Problem 1, since it asks us to 
 * rewrite each function as an object method. The remaining to requirements are met in the main method.
 * @author Max Krawczyk
 */
public class Rational 
{
   private int numerator;
   private int denominator;
   // class with two ints, numerator, denominator, meets requirement #1
   
   public Rational()
   {
      /* strange the denominator can be 0, but the book's has a specific requirement which states:
       * "Write a constructor that takes no arguments and sets instance variables to 0" in Exercise 11-3
       * Satisfies requirement #2
       */
      numerator = 0;
      denominator = 0;
   }
   
   /**
    * Satisfies requirement #6
    * Also creates a rational with given parameters
    * @param numerator any integer numerator
    * @param denominator any integer denominator, including zero
    */
   public Rational(int numerator, int denominator)
   {
      this.numerator = numerator;
      this.denominator = denominator;
   }
   
   /**
    * This method satisfies requirement #3, a print method to print the Rational number
    */
   public void print()
   {
      //if it's 0, it's undefined, no such number
      if(denominator == 0)
      {
         System.out.print("Undefined number");
      }
      //if it's 
      else if(denominator == 1)
      {
         System.out.print(numerator);
      }
      else
      {
         System.out.print(numerator + "/" + denominator);
      }
   }
   
   /**
    * Meets requirement # 7 
    */
   public void negate()
   {
      numerator = -1 * numerator;
   }
   
   /**
    * Meets requirement #8
    */
   public void invert()
   {
      int temp = denominator;
      denominator = numerator;
      numerator = temp;
   }
   
   /**
    * Meets requirement #9
    * @return the rational number expressed as a double
    */
   public double toDouble()
   {
      return (numerator / denominator);
   }

   /**
    * Meets requirement #10
    * @return a rational number that is equal to the given rational number but reduced
    */
   public Rational reduce()
   {
      int GCD = gcd(numerator, denominator);
      return new Rational(numerator / GCD, denominator / GCD);
   }
   
   /**
    * Meets requirement #11
    * @param otherRational the other rational to add with the given
    * @return the sum
    */
   public Rational add(Rational otherRational)
   {
      //find a common denominator by multiplying, not necessarily least.
      int commonDenominator = this.denominator * otherRational.denominator;
      //adding rewrite numerator by multiplying by the common denominator and then add them to find new numerator
      int numerator = this.numerator * commonDenominator + otherRational.denominator * commonDenominator;
      Rational answer = new Rational(numerator, commonDenominator);
      answer.reduce();
      return answer;
   }
   
   /**
    * computes GCD of two ints, a and b
    * @param a first int
    * @param b second int
    * @return the GCD
    */
   public int gcd(int a, int b)
   {
      if(b == 0)
      {
         return a;
      }
      
      return(gcd(b, a % b));
   }
}
