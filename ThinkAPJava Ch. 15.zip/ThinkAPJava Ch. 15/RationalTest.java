/**
 * This rational test class makes errors and describes the difference between object methods and class methods.
 * These are all errors, but intended so it meets the requirement of Exercise 15-4, number 2. 
 * @author Max Krawczyk
 */
public class RationalTest 
{
   public static void main(String[] args)
   {
      Rational r1 = new Rational(5,6);
      Rational r2 = new Rational(3,1);
      Rational r3 = new Rational(2,0);
      Rational r4 = new Rational(8,6);
      Rational r5 = new Rational(1261346,5462);
      
      r5.reduce().print();
   }

}
