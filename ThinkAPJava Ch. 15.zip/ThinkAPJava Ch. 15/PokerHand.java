/**
 * Submission for exercise 15-5, see word doc for explanation.
 * @author Max Krawczyk
 */
public class PokerHand extends Deck //this is the definition of the class, meets requirement number 2
{
   private Card[] hand;
   public static int numberCards = 5; // meets requirement 9, can change hard coded value to 5 or 7 to match it.
   
   /**
    * Generates an empty hand
    */
   public PokerHand()
   {
      hand = new Card[5];
   }
   
   /**
    * generates the given hand
    * @param hand
    */
   public PokerHand(Card[] hand)
   {
      this.hand = hand;
   }
   
   
  /**
   * Deal method, meets requirement 3 in 15-5
   * @return a poker hand, dealt randomly
   */
   public void deal()
   {
      Deck deck = new Deck();
      deck.shuffle();
      for(int i = 0; i < hand.length; i++)
      {
         hand[i] = deck.cards[i];
      }
   }
   
   /**
    * Meets requirement 5, determines flush
    * @return true if flush, else false
    */
   public boolean hasFlush()
   {
      for(int i = 0; i < hand.length - 1; i++)
      {
         if(hand[i].suit != hand[i + 1].suit)
         {
            return false;
         }
      }
      return true;
   }
   
   /**
    * Meets requirement 6, determines 3 of kind
    * @return true if three of kind, else false
    */
   public boolean hasThreeKind()
   {
      int numberOfMatch = 0; //0 since a card will match with itself, 3 matches makes three of kind.
      for(int i = 0; i < hand.length; i++)
      {
         for(int j = 0; j < hand.length; j++)
         {
            if(hand[i].rank == hand[j].rank)
            {
               numberOfMatch += 1;
            }          
         }
         if(numberOfMatch < 3)
         {
            numberOfMatch = 0;
         }
         else
         {
            return true;
         }
      }
      return false;
   }
   
   /**
    * other method to check, meets requirement 8.
    * @return true if four of kind, else false;
    */
   public boolean hasFourKind()
   {
      int numberOfMatch = 0; //0 since a card will match with itself, 3 matches makes three of kind.
      for(int i = 0; i < hand.length; i++)
      {
         for(int j = 0; j < hand.length; j++)
         {
            if(hand[i].rank == hand[j].rank)
            {
               numberOfMatch += 1;
            }
         }
         if(numberOfMatch < 4)
         {
            numberOfMatch = 0;
         }
         else
         {
            return true;
         }
      }
      return false;
   }
   
   // meets requirements 4 and 7, runs a loop hundreds of times 
   public static void main(String[] args)
   {
      for(int i = 0; i < 10000; i++)
      {
         PokerHand hand = new PokerHand();
         hand.deal();
         
         if(hand.hasFlush())
         {
            System.out.println("Has Flush!");
         }
         if(hand.hasThreeKind())
         {
            System.out.println("Has Three Kind!");
         }
         if(hand.hasFourKind())
         {
            System.out.println("Has Four Kind!");
         }
      }

   }
}
